#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc

xbmc.executebuiltin('Container.Update(plugin://plugin.video.youtube/channel/UCi8jhNF5CuD2z_rkd1YIlQw/)')

