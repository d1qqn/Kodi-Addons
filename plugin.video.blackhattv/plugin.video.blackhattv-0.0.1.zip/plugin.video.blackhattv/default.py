# :)

import xbmc



xbmc.executebuiltin('Container.Update(plugin://plugin.video.youtube/channel/UCJ6q9Ie29ajGqKApbLqfBOg/)')