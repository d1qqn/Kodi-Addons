# :)

import xbmc



xbmc.executebuiltin('Container.Update(plugin://plugin.video.youtube/channel/UC6Om9kAkl32dWlDSNlDS9Iw/)')