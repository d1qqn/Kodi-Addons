# :)

import xbmc



xbmc.executebuiltin('Container.Update(plugin://plugin.video.youtube/channel/UCGBpxWJr9FNOcFYA5GkKrMg/)')