# :)

import xbmc



xbmc.executebuiltin('Container.Update(plugin://plugin.video.youtube/channel/UC3s0BtrBJpwNDaflRSoiieQ/)')