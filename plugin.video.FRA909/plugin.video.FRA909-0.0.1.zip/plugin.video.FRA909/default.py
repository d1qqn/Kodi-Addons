# :)

import xbmc



xbmc.executebuiltin('Container.Update(plugin://plugin.video.youtube/channel/UCMdX8sk9PTL-B12u4b_g8ow/)')